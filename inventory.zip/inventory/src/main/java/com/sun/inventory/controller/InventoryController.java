package com.sun.inventory.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/inventories")
public class InventoryController {

    @GetMapping
    public List<String> getInventories() {
        return getInventoriesList();

    }

    @GetMapping("/byName")
    public List<String> getInventoriesByName(
            @RequestParam("name")
            String inventoryName) {
        return getInventoriesList()
                .stream()
                .filter(inventory -> inventory.contains(inventoryName))
                .toList();

    }

    public List<String> getInventoriesList() {
        return List.of("PRODUCT", "SERVICE", "SUPPORT");
    }

}
